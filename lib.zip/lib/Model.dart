import 'package:flutter/material.dart';
//import 'package:naya/Agentprofile/agentdashboard.dart';
//import 'package:naya/new.dart';
import 'package:naya/localization/localizations_constants.dart';
import 'package:naya/main.dart';
import 'dart:ui';
class myData{
  String name,accnum,code,accname,role,dis,state,url,uid;
  myData(this.name,this.role,this.dis,this.state,this.accname,this.accnum,this.code,this.url,this.uid);
}
class AgentdDeatils{
  String name,gender,email,phn,aadharnum,dob,occupation,village,district,state,mandal,pin,accname,ifsc,count;
  AgentdDeatils(this.name,this.gender,this.email,this.phn,this.aadharnum,this.dob,this.occupation,this.village,this.district,this.state,this.mandal,this.pin,this.accname,this.ifsc,this.count);
}

class Customerdata{
  String customername;
  String date,status,id;
  Customerdata(this.customername,this.date,this.status,this.id);
}
class Customerfulldetails{
  String customername,enid,endate,status,vehicle,brand,model;
  Customerfulldetails(this.customername,this.enid,this.endate,this.status,this.vehicle,this.brand,this.model);
}
class Translateddetails{
 String  agentname,mail,occupation,dis,region,category,model,brand,payment;
 Translateddetails(this.agentname,this.mail,this.occupation,this.dis,this.region,this.category,this.model,this.brand,this.payment);
}
void changeLanguage(Language language,BuildContext context)async{
       Locale _temp=await setLocale(language.languageCode);
       MyApp.setLocale(context,_temp);
  }
class Language{
  final int id;
  final String name;
  final String languageCode;
  Language(this.id,this.name,this.languageCode);
  static List<Language> languageList(){
    return <Language>[
Language(1, 'English', 'en'),
Language(2, 'Hindi', 'hi'),
Language(3, 'తెలుగు','te'),
Language(4, 'தமிழ்', 'ta'),


    ];
  }
  
}
Map<String, IconData> iconMapping = {
  'completed' : Icons.check_circle,
  'inprogress' : Icons.hourglass_empty,
  'notprogressed' : Icons.cancel,
};
Map<String, String> filterMapping = {
  'Customername' : 'customername',
  'Vehicle' : 'vehicle',
  'Date' : 'endate',
  'Progress':'status',
  'Enquiryid':'enid',
  'Brand':'brand',
  'Model':'model',
};

class StateModel {
  String state;
  List<String> districts;

  StateModel({this.state, this.districts});

  StateModel.fromJson(Map<String, dynamic> json) {
    state = json['state'];
    districts = json['districts'].cast<String>();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['state'] = this.state;
    data['districts'] = this.districts;
    return data;
  }
}
