//import 'dart:async';
import 'package:flutter/material.dart';
//import 'package:firebase_dynamic_links/firebase_dynamic_links.dart';
//import 'package:flutter/services.dart';

class Offer extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => OfferState();
}

class OfferState extends State<Offer> {
@override
  void initState() {
    super.initState();
  }
   @override
  Widget build(BuildContext context) {
    return Material(
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Dynamic Links Example'),
        ),
        body: Builder(builder: (BuildContext context) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
           
              ],
            ),
          );
        }),
      ),
    );
  }
}
