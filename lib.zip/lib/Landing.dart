import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
//import 'package:naya/Agentprofile/Agent.dart';
import 'package:naya/Dashboard.dart';
//import 'package:naya/authservice.dart';
//import 'package:naya/new.dart';
class LandingPage extends StatefulWidget {
  @override
  _LandingPageState createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> {
 String verify,notverify;
 DatabaseReference ref=FirebaseDatabase.instance.reference();

 @override
void initState(){
  super.initState();
  FirebaseAuth.instance.currentUser().then((user) {
var uid = user.uid;
print(uid);
DatabaseReference ref = FirebaseDatabase.instance.reference();
//obtaning the details of the user
ref.child('VerifiedAgents').orderByChild('UID').equalTo('$uid').once().then((value){
if(value.value!=null){
  setState(() {
   verify='true';  
  });
}
else{
  setState(() {
    verify='false';
  });
}
});
ref.child('NotVerifiedAgnets').child('$uid').child('Profile').once().then((value){
if(value.value!=null){
  setState(() {
    notverify='true';
  });
}
else{
  setState(() {
    notverify='false';
  });
}
});
 });
 if(verify=='true'){
   print(verify);
   Navigator.of(context).pushReplacement(
        new MaterialPageRoute(builder: (context) => new Dashboard()));
 }
}


Widget build(BuildContext context) {
  if(verify=='true' && notverify=='false'){
    print('user verified');   
    //redirect to agent dasnboard
  }
  else if(verify=='false' && notverify=='false'){
    print('user not filled details');
    //redirect to agnet
  }
  else if(verify=='false' && notverify=='true'){
    print('user not verified');
    //redirect to dasboard
  }
   return Scaffold(
      appBar: new AppBar(
        centerTitle: true,
        title: new Text('WELCOME TO NAYAGADI AGENT'),
        backgroundColor: Colors.red[700],
      ),
      body:
     IconButton(
              iconSize: 50.0,
      icon:Icon(Icons.content_paste),
      color: Colors.red[700],
      onPressed:(){
         Navigator.of(context).push(
        new MaterialPageRoute(builder: (context) => new Dashboard()));
      }
    ),
//       Center(
//         child: CircularProgressIndicator(backgroundColor:Colors.indigo,valueColor:AlwaysStoppedAnimation<Color>(Colors.orange),),
// //         child: new RaisedButton(onPressed: (){
//  AuthService().signOut();
//         },
//         child:Text('Signout'),
//         )
    
        
    );
  }
  
}
