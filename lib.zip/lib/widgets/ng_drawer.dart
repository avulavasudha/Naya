import 'package:flutter/material.dart';

class NGDrawer extends StatefulWidget{
  @override
  State<StatefulWidget> createState() => new _NGDrawerState();
}

class _NGDrawerState extends State<NGDrawer>{
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        children: <Widget>[
          DrawerHeader(
            child: Text('NG MENU',
              style: new TextStyle(
                color: Colors.white,
                fontSize: 30.0,
              ),
            ),
            decoration: BoxDecoration(
              color: Colors.red[700],
            ),
          ),

          //DASHBOARD
          ListTile(
            title: Text('Dashboard'),
            onTap: (){
              Navigator.pop(context);

              //Navigator.push(context,MaterialPageRoute(builder: (context) => AgentDashBoard()));
            },
          ),

        ],
      ),
    );
  }
}