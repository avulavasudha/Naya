import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:async';
import 'package:url_launcher/url_launcher.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
//import 'package:firebase_analytics/firebase_analytics.dart';
//import 'package:naya/Agentprofile/agentdashboard.dart';
import 'package:firebase_dynamic_links/firebase_dynamic_links.dart';
class New extends StatefulWidget {
  @override
_NewState createState() => _NewState();
}
class _NewState extends State<New> {
  String link1,referName;
  String _linkMessage;
  bool _isCreatingLink = false;
  String _testString =
      "To test: long press link and then copy and click from a non-browser "
      "app. Make sure this isn't being tested on iOS simulator and iOS xcode "
      "is properly setup. Look at firebase_dynamic_links/README.md for more "
      "details.";

DatabaseReference ref = FirebaseDatabase.instance.reference();
@override
void initState(){
super.initState();
FirebaseAuth.instance.currentUser().then((user) {
if (user != null) {
user.getIdToken().then((token) {
Map<dynamic,dynamic> tokenMap = token.claims;
var uid=tokenMap['sub'];
print(uid);
ref.child('VerifiedAgents').orderByChild('UID').equalTo('$uid').once().then((value){
var a=value.value.keys;
for(var i in a){
  print(i);

 link1 = "https://mygame.example.com/?invitedby=" + i;
setState(() {
  
});
ref.child('VerifiedAgents').child('$i').child('Profile').once().then((value){
  var data=value.value;

 referName=data['Name'];
 setState(() {
   
 });
 print(referName);
});
initDynamicLinks();
}
});
});
}
});
}

void initDynamicLinks() async {
    final PendingDynamicLinkData data =
        await FirebaseDynamicLinks.instance.getInitialLink();
    final Uri deepLink = data?.link;
 final _auth=FirebaseAuth.instance;
  final FirebaseUser user = await _auth.currentUser();
     if (user==null &&deepLink != null ) {
  var iPost=deepLink.pathSegments.contains('invitedby');
  if(iPost){
    var title=deepLink.queryParameters['invitedby'];
    if(title!=null){
      //naviagte to one page
      }
    else{
       //
print('not via dynamic link');
    }
    createAnonymousAccountWithReferrerInfo(title);
  }
    var x=deepLink.query;
    print(x);
    var y=deepLink.hasQuery;
    print(y);
      print(deepLink);
      Navigator.pushNamed(context, deepLink.path);
    }
    else{
          print('not via dynamic link');
    }


    FirebaseDynamicLinks.instance.onLink(
        onSuccess: (PendingDynamicLinkData dynamicLink) async {
      final Uri deepLink = dynamicLink?.link;

      if (deepLink != null) {
        print(deepLink.path);
        Navigator.pushNamed(context, deepLink.path);
      }
    }, onError: (OnLinkErrorException e) async {
      print('onLinkError');
      print(e.message);
    });
  }
  //creating dynamic link
  Future<void> _createDynamicLink(bool short) async {
    setState(() {
      _isCreatingLink = true;
    });

    final DynamicLinkParameters parameters = DynamicLinkParameters(
      uriPrefix: 'https://nayagadiapp.page.link',
      link: Uri.parse(link1),
      androidParameters: AndroidParameters(
        packageName: 'com.example.naya',
        minimumVersion: 0,
      ),
      dynamicLinkParametersOptions: DynamicLinkParametersOptions(
        shortDynamicLinkPathLength: ShortDynamicLinkPathLength.short,
      ),
      // iosParameters: IosParameters(
      //   bundleId: null,
      //   minimumVersion: '0',
      // ),
    );

    Uri url;
    if (short) {
      final ShortDynamicLink shortLink = await parameters.buildShortLink();
      url = shortLink.shortUrl;
    } else {
      url = await parameters.buildUrl();
      print(url);
    }

    setState(() {
      _linkMessage = url.toString();
      _isCreatingLink = false;
    });
  }


 @override
  Widget build(BuildContext context) {
    return Material(
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Dynamic Links Example'),
        ),
        body: Builder(builder: (BuildContext context) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                ButtonBar(
                  alignment: MainAxisAlignment.center,
                  children: <Widget>[
                    RaisedButton(
                      onPressed: !_isCreatingLink
                          ? () => _createDynamicLink(false)
                          : null,
                      child: const Text('Get Long Link'),
                    ),
                    RaisedButton(
                      onPressed: !_isCreatingLink
                          ? () => _createDynamicLink(true)
                          : null,
                      child: const Text('Get Short Link'),
                    ),
                  ],
                ),
                InkWell(
                  child: Text(
                    _linkMessage ?? '',
                    style: const TextStyle(color: Colors.blue),
                  ),
                  onTap: () async {
                    if (_linkMessage != null) {
                      print(_linkMessage);
                      await launch(_linkMessage);
                    }
                  },
                  onLongPress: () {
                    Clipboard.setData(ClipboardData(text: _linkMessage));
                    Scaffold.of(context).showSnackBar(
                      const SnackBar(content: Text('Copied Link!')),
                    );
                  },
                ),
                Text(_linkMessage == null ? '' : _testString)
              ],
            ),
          );
        }),
      ),
    );
  }
  createAnonymousAccountWithReferrerInfo(var x){
      // AuthCredential credential = PhoneAuthProvider.getCredential(verificationId: null, smsCode: null);
      FirebaseAuth.instance.signInAnonymously().then((value)async{
      FirebaseUser user1=await FirebaseAuth.instance.currentUser();
      ref.child("users").child(user1.uid).set({
       "refered_by":x
      });
      });
     print('user created anonymously');
    
}
void getCredential(String email, String password) {
        //AuthCredential credential = PhoneAuthProvider.getCredential(verificationId: email, smsCode:password);
}
    void linkCredential(AuthCredential credential)async{
     // final _auth=FirebaseAuth.instance;
//final FirebaseUser user = await _auth.currentUser();
   // AuthResult result = await user.linkWithCredential(credential);
    
        // [END ddl_referral_link_cred]
    }
}
