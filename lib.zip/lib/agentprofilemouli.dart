import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:naya/Model.dart';
import 'package:naya/localization/localizations_constants.dart';
import 'package:naya/widgets/ng_widgets.dart';
class AgentProfilemouli extends StatefulWidget {
  @override
  _AgentProfilemouliState createState() => _AgentProfilemouliState();
}
class _AgentProfilemouliState extends State<AgentProfilemouli> {
List compeletedcount=[];
List inprogresscount=[];
List notprogressedcount=[];
List<myData>allData=[];
@override
  void initState() {
  super.initState();
FirebaseAuth.instance.currentUser().then((user) {
var uid = user.uid;
print(uid);
DatabaseReference ref = FirebaseDatabase.instance.reference();
//obtaning the details of the user
   ref.child('VerifiedAgents').orderByChild('UID').equalTo('$uid').once().then((value){

print(value.value);
var a=value.value.keys;
print(a);
for(var i in a){
ref.child('VerifiedAgents').child('$i').child('Profile').once().then((DataSnapshot s){
     var data = s.value;
     var name=data['Name'];
     var role=data['Role'];
    var district=data['District'];
    var state=data['State'];
    //var accName=data['Name of Account holder'];
    var accNumber=data['Account numer'];
    var code=data['IFSC code'];
    var url=data['Image Url'];
    var aanum=data['Aadhar number'];
    var id=i;
    ref.child('VerifiedAgents').child('$i').child('FormEnquires').once().then((snap){
    var key=snap.value.keys;
    print('form keys');
    print(key);
    for(var j in key){
      ref.child('VerifiedAgents').child('$i').child('FormEnquires').child('$j').orderByKey().equalTo('Status').once().then((va){
        var sort=va.value;
        if(sort['Status']=='completed'){
          print('ppp');
          compeletedcount.add(j);
         setState(() {
           
         });
         print(compeletedcount.length);
        }
        if(sort['Status']=='inprogress'){
          print('ppp');
          inprogresscount.add(j);
         setState(() {
           
         });
         print(compeletedcount.length);
        }
        else if(sort['Status']=='notprogressed'){
          print('ppp');
          notprogressedcount.add(j);
         setState(() {
           
         });
         print(compeletedcount.length);
        }
         print('hello');
        
        // print(compeletedcount.length);
      });
       }
    
myData d = new myData(
        name,role,district,state,aanum,accNumber,code,url,id
       );
             allData.add(d);
      setState(() {
      });
      });
});
}
});
});

}
Widget build(BuildContext context) {
  //print(list);
  //vasu();
    return Scaffold(
      appBar: ngAppBar(getTranslated(context,'profile'), context
      ),
       body: new Container(
          child:new Center(
          child: allData.length == 0
              ? new CircularProgressIndicator(backgroundColor:Colors.indigo,valueColor:AlwaysStoppedAnimation<Color>(Colors.orange),)
              : new ListView.builder(
            itemCount: 1,
            itemBuilder: (_, index) {
              return UI(
                allData[index].name,
                allData[index].role,
                allData[index].dis,
                allData[index].state,
                allData[index].accname,
                allData[index].accnum,
                allData[index].code,
                allData[index].url,
                allData[index].uid,
                compeletedcount.length,
                inprogresscount.length,
                notprogressedcount.length,
              );
            },
      )),
    )
    );
  }
  Widget UI(var name,var role,var dis,var state,var acnam,var accnum,var code,var url,var id,var completedcount,var inprogresscount,var notprogressedcount) {
    return SingleChildScrollView(
      padding: EdgeInsets.only(left: 30.0, right: 40.0, top: 20.0),
      child: Column(
        children: <Widget>[ 
          // profile picture
          CircleAvatar(
        radius:100,
        backgroundColor: Colors.white,
        child: ClipOval(
            child:new SizedBox(
                width:180.0,
                height:180.0,
                child:Image.network(url,
                  fit: BoxFit.fill,
                )
            )
        ),
      ),
          SizedBox(height: 20,),

          // profile details
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround, 
            children: <Widget>[
              // Fields
              Column(
                crossAxisAlignment: CrossAxisAlignment.start, 
                children: <Widget>[
                  ngProfileField('Agent Name'),
                  ngProfileField('Agent ID'),
                  ngProfileField('Special Role'),
                  ngProfileField('Enq Done'),
                  ngProfileField('Enq Progreesed'),
                  ngProfileField('Enq NotProgressed'),
                  ngProfileField('No. of Referrals'),
                  ngProfileField('IFSC code'),
                  ngProfileField('Aadhaar Number'),
                  ngProfileField('District'),
                  ngProfileField('State'),
                ],
              ),

              // :-
              Column(
                children: <Widget>[
                  ngProfileField(': -'),
                  ngProfileField(': -'),
                  ngProfileField(': -'),
                  ngProfileField(': -'),
                  ngProfileField(': -'),
                  ngProfileField(': -'),
                  ngProfileField(': -'),
                  ngProfileField(': -'),
                  ngProfileField(': -'),
                  ngProfileField(': -'),
                  ngProfileField(': -'),
                ],
               ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  ngProfileFieldValue('$id '),
                  ngProfileFieldValue('$name'),
                  ngProfileFieldValue('$role'),
                  ngProfileFieldValue('$completedcount'),
                  ngProfileFieldValue('$inprogresscount'),
                  ngProfileFieldValue('$notprogressedcount'),
                  ngProfileFieldValue('No. of Referrals'),
                  ngProfileFieldValue('$code'),
                  ngProfileFieldValue('$acnam'),
                  ngProfileFieldValue('$dis'),
                  ngProfileFieldValue('$state'),
                ],
              ),
            ],
          ), 
          SizedBox(height: 20,),
        ],
      ),
    );
  }
  }