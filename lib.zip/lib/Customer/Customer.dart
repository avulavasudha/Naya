import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:naya/localization/localizations_constants.dart';
import 'package:naya/Agentprofile/agentdashboard.dart';
import 'package:intl/intl.dart';
import 'package:naya/states/india.dart';
import 'package:naya/states/indianDistrictCode.dart';
import 'package:naya/states/indianStateCode.dart';
import 'package:naya/widgets/ng_widgets.dart';
class Customer extends StatefulWidget {
  @override
  _CustomerState createState() => _CustomerState();
}
class _CustomerState extends State<Customer> {
  GlobalKey<FormState> _key = new GlobalKey();
  bool _autovalidate = false;
  String id='NGE_';
  String name,number,mail,cid,stab,c,enquiryid;
  List paymentlist=['Loan','EMI','Single Payment'];
  List brand=['pleasure','Jupyter','Tvs'];
  List category=['Car','Bike','Tractor','Scooty'];
  List model=['hhhhj','bbbb'];
  var stateslist=stateCodes.keys;
  var districtlist=districtCodes.keys;
  String selectedpayment,selectedcategory,selectedbrand,selectedmodel,selectedoccupation;
  TextEditingController dateCtl = TextEditingController();
  List count=[];
  Repoistry repo=Repoistry();
  List<String>_states=["Select State"];
  List<String>_district=["Select District"];
  String selectedDis="Select District";
  String selectedRegion="Select State";
  @override
   void initState(){
     _states=List.from(_states)..addAll(repo.getStates());
     print(stateslist);
    super.initState();
     FirebaseAuth.instance.currentUser().then((user) {
        if (user != null) {
          user.getIdToken().then((token) {
            Map<dynamic,dynamic> tokenMap = token.claims;
           var uid=tokenMap['sub'];
            print(uid);
            DatabaseReference ref=FirebaseDatabase.instance.reference();
ref.child('VerifiedAgents').once().then((value){
   var key=value.value.keys;
   print(key);
   for(var i in key){
     ref.child('VerifiedAgents').child('$i').child('FormEnquires').once().then((value){
       if(value.value!=null){
       var key2=value.value.keys;
       print(key2);
       for(var j in key2){
         count.add(j);
         setState(() {
           
         });
       }
       print(count.length);
       print(value.value);
       }
     });
   }
});
          });
        }
     });
      }
      void onSelectedState(String value){
        print(value);
        setState(() {
          selectedDis='Select District';
          _district=['Select District'];
          selectedRegion=value;
          _district=List.from(_district)..addAll(repo.getLocaleByState(value));
        });
      }
      void onSelectedLGA(String value){
        setState(() {
          selectedDis=value;
        });
      }
   
  Widget build(BuildContext context) {
    print(count.length);
         List occupationlst=[getTranslated(context, 'Stu'),getTranslated(context, 'hw'),getTranslated(context, 'fm'),getTranslated(context, 'ge'),getTranslated(context, 'in'),getTranslated(context, 'sk'),];
        return Scaffold(
      appBar: ngAppBar(getTranslated(context,'title'), context),
      body:SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.all(20.0),
          child:Form(
            key: _key,
            autovalidate: _autovalidate,
        child: Column(
           mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment:CrossAxisAlignment.center,
          children: <Widget>[
            new SizedBox(height:20.0),
             Center(child:Text('CUSTOMER',style:TextStyle(fontSize:26),)),
            Center(child:Text('DETAILS',style:TextStyle(fontSize:26),)),
            new SizedBox(height:10.0),
           TextFormField(
                decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(8)),
                            borderSide: BorderSide(color: Colors.grey[200])
                        ),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(8)),
                            borderSide: BorderSide(color: Colors.grey[300])
                        ),
                        filled: true,
                        fillColor: Colors.grey[100],
                        hintText: getTranslated(context, 'name_hint')
                      ),
                  validator: validatefullname,
                  onSaved: (val) {
                     name = val;
                },),
                      new SizedBox(height: 10.0),
                                 TextFormField(
                                    keyboardType: TextInputType.phone,
                decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(8)),
                            borderSide: BorderSide(color: Colors.grey[200])
                        ),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(8)),
                            borderSide: BorderSide(color: Colors.grey[300])
                        ),
                        filled: true,
                        fillColor: Colors.grey[100],
                        hintText: getTranslated(context, 'phn')
                      ),
                  validator: validatenumber,
                  onSaved: (val) {
                     number = val;
                },),
                new SizedBox(height: 10.0),
                TextFormField(
                decoration: InputDecoration(
                        enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(8)),
                            borderSide: BorderSide(color: Colors.grey[200])
                        ),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(8)),
                            borderSide: BorderSide(color: Colors.grey[300])
                        ),
                        filled: true,
                        fillColor: Colors.grey[100],
                        hintText: getTranslated(context, 'mail')
                      ),
                  validator: validateEmail,
                  onSaved: (val) {
                     mail = val;
                },),
                      new SizedBox(height: 10.0),
                      TextFormField(
       controller: dateCtl,
       decoration: InputDecoration(
        enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(8)),
                            borderSide: BorderSide(color: Colors.grey[200])
                        ),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(8)),
                            borderSide: BorderSide(color: Colors.grey[300])
                        ),
                        filled: true,
                        fillColor: Colors.grey[100],
                        labelText: getTranslated(context, 'Dob'),
       hintText: "Ex. Insert your dob",), 
       onTap: () async{
DateTime date = DateTime(1900);
FocusScope.of(context).requestFocus(new FocusNode());
date = await showDatePicker(
              context: context, 
              initialDate:DateTime.now(),
              firstDate:DateTime(1900),
              lastDate: DateTime.now());
              var date1=DateTime.parse(date.toString());
dateCtl.text ="${date1.day}-${date1.month}-${date1.year}";
},
validator: validateBirth,
      onSaved: (value) {
        dateCtl.text= value;
      },),
      new SizedBox(height: 20.0,),
                     DropdownButtonFormField(
                   decoration: InputDecoration(
                      enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(8)),
                            borderSide: BorderSide(color: Colors.grey[200])
                        ),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(8)),
                            borderSide: BorderSide(color: Colors.grey[300])
                        ),
                        filled: true,
                        fillColor: Colors.grey[100],
                        ),
                   hint: Text(getTranslated(context, 'Occ')),
                       isDense: true,
                        validator:(value) =>value==null?'field required':null,
                    items: occupationlst.map<DropdownMenuItem<String>>((value){
                         return DropdownMenuItem<String>(
                           value: value,
                           child: Text(value),);
                       }).toList(),
                      value:selectedoccupation,
                       onChanged: (newvalue){
                        setState(() {
                           selectedoccupation=newvalue;
                            
                         }); },),
                                 new SizedBox(height:20.0),
               
                 DropdownButtonFormField<String>(
                   decoration: InputDecoration(
                      enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(8)),
                            borderSide: BorderSide(color: Colors.grey[200])
                        ),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(8)),
                            borderSide: BorderSide(color: Colors.grey[300])
                        ),
                     filled: true,
                     fillColor: Colors.grey[100],
                   ),
                   hint: Text(getTranslated(context, 'stat_hint')),
                       
                       isDense: true,
                        onChanged: (value) => onSelectedState(value),
                        value:selectedRegion,
                       validator:(value) =>value==null?'field required':null,
                  items: _states.map<DropdownMenuItem<String>>((value){
                         return DropdownMenuItem<String>(
                           value: value,
                           child: Text(value),);
                       }).toList(),
                       ),

                       new SizedBox(height:20.0),
                         DropdownButtonFormField<String>(
                   decoration: InputDecoration(
                      enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(8)),
                            borderSide: BorderSide(color: Colors.grey[200])
                        ),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(8)),
                            borderSide: BorderSide(color: Colors.grey[300])
                        ),
                        filled: true,
                        fillColor: Colors.grey[100]
                   ),
                   hint: Text(getTranslated(context, 'dis_hint')),
                     
                       isDense: true,
                       onChanged: (value) => onSelectedLGA(value),
                       value:selectedDis,
                       
                       validator:(value) =>value==null?'field required':null,
                  items: _district.map<DropdownMenuItem<String>>((value){
                         return DropdownMenuItem<String>(
                           value: value,
                           child: Text(value),);
                       }).toList(),),
                 new SizedBox(height:20.0),  
             DropdownButtonFormField<String>(
                   decoration: InputDecoration(
                     enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(8)),
                            borderSide: BorderSide(color: Colors.grey[200])
                        ),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(8)),
                            borderSide: BorderSide(color: Colors.blue)
                        ),
                        filled: true,
                        fillColor: Colors.grey[100],
                      ),
                   hint: Text("Cateogory"),
                      isDense: true,
                       validator:(value) =>value==null?'field required':null,
                    items: category.map<DropdownMenuItem<String>>((value){
                         return DropdownMenuItem<String>(
                           value: value,
                           child: Text(value),);
                       }).toList(),
                  value:selectedcategory,
                        onChanged: (newvalue){
                        setState(() {
                           selectedcategory=newvalue;
                          });
                         },
                      ),
          new SizedBox(height:10.0),
               DropdownButtonFormField<String>(
                   decoration: InputDecoration(
                     enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(8)),
                            borderSide: BorderSide(color: Colors.grey[200])
                        ),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(8)),
                            borderSide: BorderSide(color: Colors.grey[300])
                        ),
                        
                        filled: true,
                        fillColor: Colors.grey[100],
                       ),
                   hint: Text("Model"),
                      isDense: true,
                       validator:(value) =>value==null?'field required':null,
                  items: model.map<DropdownMenuItem<String>>((value){
                         return DropdownMenuItem<String>(
                           value: value,
                           child: Text(value),);
                       }).toList(),
                      value:selectedmodel,
                        onChanged: (newvalue){
                        setState(() {
                           selectedmodel=newvalue;
                          });
},),
                      new SizedBox(height:10.0),
                      DropdownButtonFormField<String>(
                   decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(8)),
                            borderSide: BorderSide(color: Colors.grey[200])
                        ),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(8)),
                            borderSide: BorderSide(color: Colors.grey[300])
                        ),
                        
                        filled: true,
                        fillColor: Colors.grey[100],
                       ),
                   hint: Text("Brand"),
                      isDense: true,
                       validator:(value) =>value==null?'field required':null,
                    items: brand.map<DropdownMenuItem<String>>((value){
                         return DropdownMenuItem<String>(
                           value: value,
                           child: Text(value),);
                       }).toList(),
                      value:selectedbrand,
                        onChanged: (newvalue){
                        setState(() {
                           selectedbrand=newvalue;
                            });},),
                      new SizedBox(height:10.0),
                      DropdownButtonFormField<String>(
                   decoration: InputDecoration(
                     enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(8)),
                            borderSide: BorderSide(color: Colors.grey[200])
                        ),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(8)),
                            borderSide: BorderSide(color: Colors.grey[300])
                        ),
                        
                        filled: true,
                        fillColor: Colors.grey[100],
                       ),
                   hint: Text("Payment"),
                      isDense: true,
                       validator:(value) =>value==null?'field required':null,
                items: paymentlist.map<DropdownMenuItem<String>>((value){
                         return DropdownMenuItem<String>(
                           value: value,
                           child: Text(value),);
                       }).toList(),
                       value:selectedpayment,
                        onChanged: (newvalue){
                        setState(() {
                           selectedpayment=newvalue;
                          });},),
                ButtonTheme(
              minWidth: 120,
            child:new RaisedButton(
              onPressed: () {
             _sendserver(count.length);
            },
          shape: new RoundedRectangleBorder(borderRadius: new BorderRadius.circular(20.0)),
          child: new Text(getTranslated(context, 'sub_hint'),style: TextStyle(fontSize:18),),
          color: Colors.redAccent,
)),
           ],
        ),)
      ))
    );
  }
  _sendserver(var count1)async{
    print(count1);
    final _auth=FirebaseAuth.instance;
    final FirebaseUser user = await _auth.currentUser();
    var uid = user.uid;
    print(uid);
if(_key.currentState.validate()){
        _key.currentState.save();
        var now = new DateTime.now();
    var timestamp=new DateFormat("dd-MM-yyyy").format(now);
    var data={
      "Name":name,
      "Mobile number":number,
      "e-mail":mail,
      "DOB":dateCtl.text,
      "Occupation":selectedoccupation,
      "District":selectedDis,
      "State":selectedRegion,
      "Category":selectedcategory,
      "Model":selectedmodel,
      "Brand":selectedbrand,
      "Payment":selectedpayment,
      "Date":timestamp,
      "Status":'notprogressed',
    };
    print(selectedDis);
    print(selectedRegion);
    for(var i in stateslist){
      if(i==selectedRegion){
         stab=stateCodes[selectedRegion];
      }
    }
    for(var i in districtlist){
      if(i==selectedDis){
         c=districtCodes[selectedDis];
      }
    }
    var count3=count1+1;
    print(c);
    enquiryid=id+stab+'_'+c+count3.toString();
    print(enquiryid);
var re=FirebaseDatabase.instance.reference();
 re.child('VerifiedAgents').once().then((DataSnapshot snap) {
 re.child('VerifiedAgents').orderByChild('UID').equalTo('$uid').once().then((value){
 var a=value.value.keys;
 for(var i in a){
   print(i);
re.child('VerifiedAgents').child('$i').child('FormEnquires').once().then((DataSnapshot s){
  
re.child('VerifiedAgents').child('$i').child('FormEnquires').child('$enquiryid').set(data).then((value){
_key.currentState.reset();
Navigator.of(context).push(
  new MaterialPageRoute(builder: (context) => new AgentDashBoard()));

});
});
 }
 });
});
}
  else{
     setState(() {
          _autovalidate=true;
        });
       
  }
  }
  
    

  }
  String validatefullname(String val) {
    return val.length == 0 ? "Enter name first" : null;
  }
  String validateaadharnumber(String val) {
     if (val.length != 12)
      return 'Enter valid aadhar number';
    else if(val.length == 0)
       return 'Enter aadhar number first';
    else 
    return null;
  }

   String validatenumber(String val) {
     if(val.length!=10){
       return "Enter valid phone number";
     }else if(val.length==0){
    return  "Enter phone number first";
    }
    else{
      return null;
    }
  }
String validateEmail(String value) {
  print(value);
  Pattern pattern =
        r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
    RegExp regex = new RegExp(pattern);
    
  if(value.length!=0 && !value.contains(regex))
      return 'Enter Valid Email';
    else
      return null;
  }

 String validateBirth(value){
   if(value.length==null){
     return "Enter dob first";
   }
   else{
     return null;
   }
}

