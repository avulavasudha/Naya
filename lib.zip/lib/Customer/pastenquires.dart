import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:naya/Model.dart';
import 'package:naya/localization/localizations_constants.dart';
import 'package:naya/Agentprofile/agentdashboard.dart';
import 'package:naya/Customer/fullenquiry.dart';
import 'package:naya/widgets/ng_widgets.dart';
class Pastenquires extends StatefulWidget {
  @override
  _PastenquiresState createState() => _PastenquiresState();
}
class _PastenquiresState extends State<Pastenquires> {
List filterlist=['Customername','Progress','Enquiryid','Vehicle','Brand','Date','Model'];
List<Customerfulldetails>data=[];
List<Customerfulldetails>filtereddata=[];
List<Customerfulldetails>sorteddata=[];
String selectedfilter;
void _showDialog() {
showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: new Text("Alert!!!!"),
          content: new Text("You did not create a enquiry to view it"),
          shape: RoundedRectangleBorder(borderRadius: 
    BorderRadius.all(Radius.circular(15))),
          actions: <Widget>[
            ButtonTheme(
            minWidth: 120,
            child:new RaisedButton(
               onPressed: () {
            Navigator.of(context).pushReplacement(
  new MaterialPageRoute(builder: (context) => new AgentDashBoard()));

          },
          shape: new RoundedRectangleBorder(borderRadius: new BorderRadius.circular(30.0)),
        child: new Text(getTranslated(context, 'ok'),style: TextStyle(fontSize:18,),),
          color: Colors.redAccent,)),
           ],
        );
      },
    );
  }
@override
  void initState() {
    super.initState();
FirebaseAuth.instance.currentUser().then((user) {
var uid = user.uid;
print(uid);
DatabaseReference ref = FirebaseDatabase.instance.reference();
//obtaning the details of the user
ref.child('VerifiedAgents').orderByChild('UID').equalTo('$uid').once().then((value){
var a=value.value.keys;
for(var i in a){
ref.child('VerifiedAgents').child('$i').child('FormEnquires').once().then((DataSnapshot s){
  if(s.value!=null){
     var key=s.value.keys;
     print(key);
     var data1 = s.value;
     print(data1);
     for(var i in key){
       print(i);
     var name=data1[i]['Name'];
    var date=data1[i]['Date'];
    var status=data1[i]['Status'];
    var vehicle=data1[i]['Category'];
    var brand=data1[i]['Brand'];
    var model=data1[i]['Model'];
   ref.child('VerifiedAgents').child('$i').child('FormEnquires').once().then((DataSnapshot s){
  
   });
     Customerfulldetails d1 = new Customerfulldetails(
       name,i,date,status,vehicle,brand,model,
    
       );
  data.add(d1);
  sorteddata=filtereddata=data;
   setState(() {
      });
    
     }
}
else{
 _showDialog();
}
});
}
});
});
}
void filtername(String value){
  print(selectedfilter);
  var x=filterMapping[selectedfilter];
  print(x);
if(x=='vehicle'){

  setState(() {
  filtereddata=filtereddata.where((element) => element.vehicle.toLowerCase().contains(value.toLowerCase())).toList();
});

}
else if(x=='endate'){
  setState(() {
  filtereddata=data.where((element) => element.endate.toLowerCase().contains(value.toLowerCase())).toList();

});
}
else if(x=='enid'){
  print('you opted id');
  setState(() {
  filtereddata=data.where((element) => element.enid.toLowerCase().contains(value.toLowerCase())).toList();

});
}
else if(x=='status'){
  print('you opted id');
  setState(() {
  filtereddata=data.where((element) => element.status.toLowerCase().contains(value.toLowerCase())).toList();

});
}
else if(x=='model'){
  print('you opted id');
  setState(() {
  filtereddata=data.where((element) => element.model.toLowerCase().contains(value.toLowerCase())).toList();

});
}
else{
  print('you opted customer name');
  setState(() {
  filtereddata=data.where((element) => element.customername.toLowerCase().contains(value.toLowerCase())).toList();

});

}

}

Widget build(BuildContext context) {
  print('filtereddata');
  print(filtereddata);
    return Scaffold(
      appBar:ngAppBar(getTranslated(context,'title'), context),
       body: new Container(

         padding: EdgeInsets.all(20),
          child:Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.center,
            children:<Widget>[
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            
                textDirection: TextDirection.rtl,
              children:<Widget>[
                     Expanded(
                       child:DropdownButtonHideUnderline(
                         child: DropdownButton(
                        hint: Text('search here'),
                    items: filterlist.map<DropdownMenuItem<String>>((value){
                         return DropdownMenuItem<String>(
                           value: value,
                           child: Text(value),);
                       }).toList(),
                      value:selectedfilter,
                       onChanged: (newvalue){
                        setState(() {
                           selectedfilter=newvalue;
                            
                         }); },),),),
                         new SizedBox(width:20.0),
              Expanded(child:TextField(
                decoration: InputDecoration(
                  prefixIcon: Icon(
                    Icons.search,
                    color: Colors.red[700],
                    ),
                        enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(30)),
                            borderSide: BorderSide(color: Colors.grey[200])
                        ),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(8)),
                            borderSide: BorderSide(color: Colors.grey[300])
                        ),
                        filled: true,
                        fillColor: Colors.grey[100],
                        hintText: 'filter here'
                      ),
                      onChanged: (value){
                             filtername(value);
                                                  },
                      ))]),
                     new SizedBox(
                        height: 20.0,
                     ) ,
              
            new Flexible(
          child: filtereddata.length == 0
              ? new CircularProgressIndicator(backgroundColor:Colors.indigo,valueColor:AlwaysStoppedAnimation<Color>(Colors.orange),)
              : new ListView.builder(
            itemCount: filtereddata.length,
            itemBuilder: (_, index) {
              return UI(
                filtereddata[index].customername,
                filtereddata[index].endate,
                filtereddata[index].status,
                filtereddata[index].enid,
                index,
              );
            
            },
      ))]),
    )
    );
  }
  Widget UI(var humidity,var moisture,var prog,var id,var index) {
  return new GestureDetector(
onTap: (){
  print(index);
  print(id);
  Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => Fullenquiry(value: id),
                ),
              );
},
  child: SingleChildScrollView(
    child:new Card(
      elevation: 10.0,
      child: new Container(
        padding: new EdgeInsets.all(20.0),
        child: new Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[ 
          new Text('$humidity',style:TextStyle(fontSize:20.0,fontWeight:FontWeight.bold),),
          new Text('$moisture',style:TextStyle(fontSize:20.0,fontWeight:FontWeight.bold),),
]),
Column(
  children:<Widget>[
  new SizedBox(width: 50.0,),
new Text('Status:',style:TextStyle(fontSize:20.0,fontWeight:FontWeight.bold),),
Icon(iconMapping [prog]),
new SizedBox(height:2.0),])
             ],
        ),
      ),
  )));
  }

}