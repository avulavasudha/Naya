import 'package:flutter/material.dart';
import 'package:naya/widgets/ng_drawer.dart';
import 'package:naya/localization/localizations_constants.dart';
import 'package:naya/widgets/ng_widgets.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:naya/Customer/fullenquiry.dart';
import 'package:naya/Agentprofile/agentdashboard.dart';
import 'package:naya/Model.dart';
class Earnings extends StatefulWidget{
  @override
  State<StatefulWidget> createState() => new _Earnings();

}
class _Earnings extends State<Earnings>{
  List<Customerdata>data=[];

  void _showDialog() {
showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: new Text("Alert!!!!"),
          content: new Text("You did not create a enquiry to view it"),
          shape: RoundedRectangleBorder(borderRadius: 
    BorderRadius.all(Radius.circular(15))),
          actions: <Widget>[
            ButtonTheme(
            minWidth: 120,
            child:new RaisedButton(
               onPressed: () {
            Navigator.of(context).pushReplacement(
  new MaterialPageRoute(builder: (context) => new AgentDashBoard()));

          },
          shape: new RoundedRectangleBorder(borderRadius: new BorderRadius.circular(30.0)),
        child: new Text(getTranslated(context, 'ok'),style: TextStyle(fontSize:18,),),
          color: Colors.redAccent,)),
           ],
        );
      },
    );
  }
  @override
  void initState(){
    super.initState();
    FirebaseAuth.instance.currentUser().then((user) {
var uid = user.uid;
print(uid);
DatabaseReference ref = FirebaseDatabase.instance.reference();
//obtaning the details of the user
ref.child('VerifiedAgents').orderByChild('UID').equalTo('$uid').once().then((value){
var a=value.value.keys;
for(var i in a){
ref.child('VerifiedAgents').child('$i').child('FormEnquires').once().then((DataSnapshot s){
  if(s.value!=null){
     var key=s.value.keys;
     print(key);
     var data1 = s.value;
     print(data1);
     for(var i in key){
       print(i);
    var name=data1[i]['Name'];
    var role=data1[i]['Date'];
    var status=data1[i]['Status'];
 Customerdata d1 = new Customerdata(
       name,role,status,i
       );
  data.add(d1);
   setState(() {
      });
     }
}
else{
 _showDialog();
}
});
}
});
});
  }
  Widget build(BuildContext context){
    return Scaffold(
 appBar:ngAppBar(getTranslated(context, 'dashboard'), context
      ),
      
      drawer: NGDrawer(),
          body:new Center(
          child: data.length == 0
              ? new CircularProgressIndicator(backgroundColor:Colors.indigo,valueColor:AlwaysStoppedAnimation<Color>(Colors.orange),)
              : new ListView.builder(
            itemCount: data.length,
            itemBuilder: (_, index) {
              return UI(
                data[index].customername,
                data[index].date,
                data[index].status,
                data[index].id,
                index,
              );
            
            },
      )
    )
    );
  }
    Widget UI(var humidity,var moisture,var prog,var id,var index) {
    print(prog);
    //print(humidity);
  return new GestureDetector(
onTap: (){
  print(index);
  print(id);
  Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => Fullenquiry(value: id),
                ),
              );
},
  child: SingleChildScrollView(
    child:new Card(
      elevation: 10.0,
      child: new Container(
        padding: new EdgeInsets.all(20.0),
        child: new Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[ 
          new Text('$humidity',style:TextStyle(fontSize:20.0,fontWeight:FontWeight.bold),),
          new Text('$moisture',style:TextStyle(fontSize:20.0,fontWeight:FontWeight.bold),),
]),
             ],
        ),
      ),
  )));
  }
}