import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:naya/Customer/Customer.dart';
import 'package:naya/localization/localizations_constants.dart';
import 'package:naya/Customer/audiotrail.dart';
import 'package:intl/intl.dart';
import 'package:jiffy/jiffy.dart';
import 'package:naya/widgets/ng_widgets.dart';
class Verified extends StatefulWidget {
  @override
_VerifiedState createState() => _VerifiedState();
}
class _VerifiedState extends State<Verified> {
DatabaseReference ref = FirebaseDatabase.instance.reference();
var countaudio=[1];
@override
void initState(){
super.initState();
FirebaseAuth.instance.currentUser().then((user) {
if (user != null) {
user.getIdToken().then((token) {
Map<dynamic,dynamic> tokenMap = token.claims;
var uid=tokenMap['sub'];
print(uid);
ref.child('VerifiedAgents').orderByChild('UID').equalTo('$uid').once().then((value){
var a=value.value.keys;
for(var i in a){
  print(i);
ref.child('VerifiedAgents').child('$i').once().then((DataSnapshot s){
      var da = s.value;
      var count=da['audioenquires'];
      countaudio.add(count);
      setState(() {
});
});
}
});
});
}
});
}
Widget build(BuildContext context){
    return Scaffold(
      appBar: ngAppBar(getTranslated(context,'title'), context),
      body:Container(
        height: 300,
        margin: EdgeInsets.only(top:150.0,left: 20.0,right: 20.0),
      padding: EdgeInsets.only(top:30.0,left: 20.0,right: 20.0),
        decoration: BoxDecoration(
    border: Border.all(color: Colors.grey),
    borderRadius: BorderRadius.all(
      Radius.circular(20),
    )
  ),
  child:Expanded(
    child: Column(
children: <Widget>[
  ngProfileField('Choose your method of entry'),
  Divider(thickness: 1.0,
      color: Colors.grey,
    ),
     Expanded(
       child:Row(
    mainAxisAlignment: MainAxisAlignment.start,
    children: <Widget>[
      Expanded(child:Column(
        children: <Widget>[
    IconButton(
              iconSize: 50.0,
      icon:Icon(Icons.mic),
      color: Colors.red[700],
      onPressed:(){
       direct();
      }
    ),
    
    new SizedBox(height: 20.0,),
     new Flexible(
          child: countaudio.length == 1
              ? new CircularProgressIndicator(backgroundColor:Colors.indigo,valueColor:AlwaysStoppedAnimation<Color>(Colors.orange),)
              : new ListView.builder(
              itemCount: 1,
            itemBuilder: (_, index) {
              return UI(
                countaudio.last
               );
            },
      )),
    // ngProfileField('Send Voice Message\n(You still have N \n chances this month)'),
 
    ])),
     VerticalDivider(
                 thickness: 1.0,
                  color: Colors.grey,
                ),
                new SizedBox(width:50),
                Column(
                  children: <Widget>[
    IconButton(
              iconSize: 50.0,
      icon:Icon(Icons.assignment),
      color: Colors.red[700],
      onPressed:(){
         Navigator.of(context).push(
        new MaterialPageRoute(builder: (context) => new Customer()));
      }
    ),
    new SizedBox(height: 20.0,),
    ngProfileField('Fill the Form\n manually'),
 
    ])
    ,])),
  ],
  ) ))
      );
}
direct()async{
 final _auth=FirebaseAuth.instance;
final FirebaseUser user = await _auth.currentUser();
var uid = user.uid;
ref.child('VerifiedAgents').orderByChild('UID').equalTo('$uid').once().then((value){
var a=value.value.keys;
for(var i in a){
  print(i);
ref.child('VerifiedAgents').child('$i').child('Profile').once().then((DataSnapshot s){
     var key=s.value.keys;
     print('key');
     print(key);
      var da = s.value;
      var time=da['timestamp'];
      print(time);
      print(time.runtimeType);
    return uploadaudio(time);
});

}
  });
    
  }
uploadaudio(var time)async{
    final _auth=FirebaseAuth.instance;
      final FirebaseUser user = await _auth.currentUser();
    var uid = user.uid;
    var now = new DateTime.now();
    var date=new DateFormat("yyyyMMdd").format(now);
    print(date);
    DateTime dd=DateTime.parse(date);
    print(dd);
    DateTime td=DateTime.parse(time);
    print(td);
    var updatedtime=Jiffy(td).add(days: 30);
final difference = dd.difference(td).inDays;
    print('difference');
    print(difference);
  ref.child('VerifiedAgents').orderByChild('UID').equalTo('$uid').once().then((value){
var a=value.value.keys;
for(var i in a){
  print(i);
ref.child('VerifiedAgents').child('$i').once().then((DataSnapshot s){
      var da = s.value;
      var count=da['audioenquires'];
      print(count);
      print(count.runtimeType);
  if(difference>=30){
    print(difference-30);
    var o=difference-30;
    var exud=Jiffy(updatedtime).subtract(days:o);
    var ud=new DateFormat("yyyyMMdd").format(exud);
    ref.child('VerifiedAgents').child('$i').update({
       "audioenquires":0
    });
    ref.child('VerifiedAgents').child('$i').child('Profile').update({
     "timestamp":ud,
    }).then((value){
 Navigator.of(context).push(
    new MaterialPageRoute(builder: (context) => new RecorderExample()));
    });
  }
  else if(difference<30 && count<3){
    Navigator.of(context).push(
    new MaterialPageRoute(builder: (context) => new RecorderExample()));
}
else if(difference<30 && count>=3){
    print('limit exceede');
        
  }
});
}
});
}
  Widget UI(var count) {
    print(count);
    int x=3-count;
  return ngProfileField('Send VoiceMessage\n(You still have $x \n chances this month)');
  }
}
