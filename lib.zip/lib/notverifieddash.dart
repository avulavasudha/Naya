import 'package:flutter/material.dart';
import 'package:naya/localization/localizations_constants.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:naya/widgets/ng_drawer.dart';
import 'package:naya/widgets/ng_widgets.dart';
class NotVerified extends StatefulWidget {
  @override
  _NotVerifiedState createState() => _NotVerifiedState();
}

class _NotVerifiedState extends State<NotVerified> {
  final f=FirebaseDatabase.instance.reference();
  @override
  void initState(){
    super.initState();
   
  }

  Widget build(BuildContext context) {
    return Scaffold(
      appBar: ngAppBar(getTranslated(context,'title'), context),
      drawer: NGDrawer(),
      body:Center(
        child: Container(
          padding: EdgeInsets.all(30.0),
          child: Text(
            "Your details are under verification.\n\nSoon you will get a call from our staff.\n\nYou can access this dashboard once you are verified.\n\nThanks for your patience.",
            textAlign: TextAlign.center,
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 24.0,
            ),
          ),
        ),
      ),
 
    );
  }
}
